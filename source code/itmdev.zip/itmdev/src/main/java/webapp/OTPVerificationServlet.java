package webapp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginDao;
import model.OTPDao;

@WebServlet("/OtpVerification")
public class OTPVerificationServlet extends HttpServlet {
	private static String custId;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession();
		String otp = request.getParameter("otp");
		// System.out.println("OTP: " +session.getAttribute("customerId"));

		OTPDao generatedOTP = new OTPDao();
		LoginDao loginDet = new LoginDao();
		
		String CustomerId = generatedOTP.getOTP(loginDet.getEmailid(),otp);
		if (CustomerId.contains("doesn't")) {
			session.setAttribute("OTPerrorMessage", "OTP Doesn't match");
			session.setAttribute("userLoggedin", false);
			request.getRequestDispatcher("loginverification.jsp").forward(request, response);
		} else {
			String uName = loginDet.getCustName(CustomerId);
			session.setAttribute("userLoggedin", true);
			if (loginDet.getUserType().equals("user")) {
				session.setAttribute("Username", uName); // setting
				request.setAttribute("userName", uName);
				session.setAttribute("FirstName", session.getAttribute("FirstName"));
				session.setAttribute("LastName", session.getAttribute("LastName"));
				session.setAttribute("userType", session.getAttribute("userType"));
				session.setAttribute("customerId", session.getAttribute("customerId"));
				request.getRequestDispatcher("Home.jsp").forward(request, response);
			}
			else if (loginDet.getUserType().equals("provider")) {
				session.setAttribute("Username", uName);
				request.setAttribute("userName", uName);
				session.setAttribute("FirstName", session.getAttribute("FirstName"));
				session.setAttribute("LastName", session.getAttribute("LastName"));
				session.setAttribute("userType", session.getAttribute("userType"));
				session.setAttribute("customerId", session.getAttribute("customerId"));
				request.getRequestDispatcher("carprovider_home.jsp").forward(request, response);
			}
			else{
				session.setAttribute("Username", uName);
				request.setAttribute("userName", uName);
				session.setAttribute("FirstName", session.getAttribute("FirstName"));
				session.setAttribute("LastName", session.getAttribute("LastName"));
				session.setAttribute("userType", session.getAttribute("userType"));
				session.setAttribute("customerId", session.getAttribute("customerId"));
				request.getRequestDispatcher("Admin.jsp").forward(request, response);
			
				
			}
		}
	}

	public void setEmailId(String customerId) {
		this.custId = customerId;
	}

	/*
	 * public void fwdSession(String fName,String lName,String uType,String
	 * custId){
	 * 
	 * session.setAttribute("Username", login.getUserName());
	 * session.setAttribute("FirstName", login.getFirstName());
	 * session.setAttribute("LastName",login.getLastName());
	 * session.setAttribute("userType",login.getuserType());
	 * session.setAttribute("customerId", login.getCustomerid()); }
	 */

}
