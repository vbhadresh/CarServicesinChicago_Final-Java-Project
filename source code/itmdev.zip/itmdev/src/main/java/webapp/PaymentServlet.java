package webapp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.LoginDao;
import model.ProviderDao;
import sources.EmailVerification;
@WebServlet("/Payment")
public class PaymentServlet extends HttpServlet {

	@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
			request.getRequestDispatcher("payment.jsp").forward(request, response);
		}
		
		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response){
			HttpSession session= request.getSession();
			ProviderDao provider = new ProviderDao();
			String selectedCar=(String) request.getAttribute("Car");
			
			provider.deleteEntry(selectedCar);
			try {
				request.setAttribute("Successfully Booked Car", selectedCar);
				/*Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Succesffully Booked a car");
				alert.setHeaderText("Booking Confirmation");*/
				//alert.setContentText("Please enter 4-digits between 2017-2030 ONLY!");
				//alert.show();
				LoginDao login= new LoginDao();
				EmailVerification.send(login.getEmailid(),"success");
				request.getRequestDispatcher("Home.jsp").forward(request, response);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		}
}

