package webapp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.ProviderDao;
import sources.LocationAPI;
@WebServlet("/Cardetailsmodule")

	
	public class CarProviderServlet extends HttpServlet {
	
	public static String emailId;
	
	public void setEmail(String email){
		emailId=email;
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.getRequestDispatcher("index.jsp").forward(request, response);

	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String zipcode=request.getParameter("zipCode");
		String location="";
		try {
			location=new LocationAPI().getUserLocation(zipcode);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Email : "+emailId);
		String car1= request.getParameter("car1");
		String car2= request.getParameter("car2");
		String car3= request.getParameter("car3");
		String[] cars= new String[3];
		cars[0]=car1;
		cars[1]=car2;
		cars[2]=car3;
		
		ProviderDao provider= new ProviderDao();
		provider.setProviderdetails(emailId,zipcode,cars);
		HttpSession session= request.getSession();
		session.setAttribute("Car1Name", car1);
		session.setAttribute("Car 2:", car2);
		session.setAttribute("Car 3:", car3);
		session.setAttribute("zipCode:", zipcode);
		session.setAttribute("City", location);
		request.getRequestDispatcher("addLocality.jsp").forward(request, response);
	}
	
}
