package webapp;

import java.util.List;

import model.ProviderDao;

public class Providercheck {
	
	public String[] getCarDetails(String CustId){
		ProviderDao provider= new ProviderDao();
		String[] prov=provider.getProviderdetails(CustId);
		return prov;
	}

	public void getEmailID(String email){
		CarProviderServlet carserv= new CarProviderServlet();
		carserv.setEmail(email);
	}
	public List<String> setzipCode(String zip){
		this.zipCode=zip;
		BookCarServlet book= new BookCarServlet();
		return book.setzipCode(zipCode);
	}
	private static String zipCode="";
}
