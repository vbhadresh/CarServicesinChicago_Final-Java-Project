package webapp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.MechanicServiceDao;
import model.ProviderDao;
@WebServlet("/Mechanic")
public class MechanicServlet extends HttpServlet {

	@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
			request.getRequestDispatcher("mechanicSevices.jsp").forward(request, response);
		}
		
		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response){
			MechanicServiceDao mechanicService= new MechanicServiceDao();
			String id=(String)request.getAttribute("emailId");
			String zipcode=request.getParameter("zipCode");
			String serviceDesc= request.getParameter("service");
			if(mechanicService.updateStatus(id,zipcode,serviceDesc)){
			HttpSession session= request.getSession();
			session.setAttribute("Service request","Successfully raised a request");
			try {
				request.getRequestDispatcher("mechanicServices.jsp").forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
}

