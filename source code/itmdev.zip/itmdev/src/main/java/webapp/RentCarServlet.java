package webapp;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.ProviderDao;
import sources.LocationAPI;


@WebServlet("/RentCarModule")
public class RentCarServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.getRequestDispatcher("index.jsp").forward(request, response);

	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response){
		HttpSession session= request.getSession();
		try{
			String fromdate=request.getParameter("fromDate");
			String todate=request.getParameter("toDate");
			String shortestdist="";
			LocationAPI location= new LocationAPI();
			System.out.println(fromdate);
			String zipcode=request.getParameter("zipCode");
			ProviderDao prov= new ProviderDao();
			
			/*List<String> zipcodes=prov.getzipCodes();
			
			String[] userZip=location.getLatLong(zipcode);
			Double[] shortest=new Double[2];
			Double[] finaldist= new Double[2];
			for(String code:zipcodes){
				int j=0;
				String[] given=location.getLatLong(code);
			for(int i=0;i<zipcodes.size();i++){
				shortest[i]=location.getShortestDist(Double.parseDouble(given[0]), Double.parseDouble(userZip[0]), Double.parseDouble(given[1]), Double.parseDouble(userZip[1]));
			}
			finaldist[j]=shortest[j];
			j++;
			}
			if(shortest[0]<shortest[1]){
				session.setAttribute("Nearestzipcode",shortest[0]);
			}else{
				session.setAttribute("Nearestzipcode",shortest[1]);
			}*/
			session.setAttribute("Nearestzipcode","60616");
			//session.setAttribute("Nearestzipcode","60661");
			request.getRequestDispatcher("bookCar.jsp").forward(request, response);
		}catch(Exception e){
			System.err.println("Error in rent car Post method");
		}
	}

}
