package webapp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginDao;
import model.OTPDao;
import model.daoModel;
import sources.EmailVerification;



@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	public LoginServlet(){
		daoModel daomod= new daoModel();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.getRequestDispatcher("index.jsp").forward(request, response);

	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String userName= request.getParameter("userName");
		String password=request.getParameter("password");
		
		if(request.getParameter("login")!=null){
			System.out.println("login clicked");
			validateCredentials(userName, password,request,response);
		}
		else if (request.getParameter("register") != null) {
			System.out.println("Register clicked");
		}

	}
	
	public void validateCredentials(String userName,String password,HttpServletRequest request,HttpServletResponse response){
		HttpSession session=request.getSession();
		try{
		LoginDao login= new LoginDao();
		OTPDao generateOtp= new OTPDao();
		boolean cred=login.getDetails(userName,password);
		if(cred){
			EmailVerification.send(login.getEmailid(),"otp");
			generateOtp.setOTP(new EmailVerification().getOtp(),login.getEmailid());
			session.setAttribute("Username", login.getUserName());
			session.setAttribute("FirstName", login.getFirstName());
			session.setAttribute("LastName",login.getLastName());
			session.setAttribute("userType",login.getUserType());
			session.setAttribute("customerId", login.getCustomerId());
			session.setAttribute("emailId",login.getEmailid());
			request.getRequestDispatcher("loginverification.jsp").forward(request, response);
		}
		else{
			System.out.println(session);
			session.setAttribute("errorMessage","Invalid Credentials. Please try again with correct input.");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		}
		catch(Exception e){
			System.err.println("Error in Fetching details from Database for Login");
		}
		
	}

}