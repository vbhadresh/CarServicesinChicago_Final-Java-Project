package webapp;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginDao;



@WebServlet("/Registeration")
public class Registeration extends HttpServlet {
	private Connection connection;
	
	public Registeration(){
		
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.getRequestDispatcher("register2.jsp").forward(request, response);

	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession();
		String id=request.getParameter("id");
		String title= request.getParameter("title");
		String firstName= request.getParameter("fName");
		String lastName= request.getParameter("lName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("pwd");
		String emailId= request.getParameter("email");
		String userType=request.getParameter("uType");
		
		LoginDao regDet=new LoginDao();
		boolean res=regDet.setCredentials(id, title, firstName, lastName, password, userType, emailId,userName);
		if(res){
			session.setAttribute("registrationStatus", "Successfully Registered. Please Login to explore CCC Motors");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		else{
			session.setAttribute("Userexists","User exists with same User name. Please try again with different user Name");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
	}
	
}
