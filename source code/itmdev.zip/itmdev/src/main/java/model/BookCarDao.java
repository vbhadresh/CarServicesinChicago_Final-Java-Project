package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class BookCarDao {
	
	public BookCarDao(){
		this.connection=new daoModel().getConnection();
		if(connection!=null){
			System.out.println("Established Connection successfully");
		}
		else{
			System.err.println("Failed to establish Connection");
		}
	}
	
	private String[] getCars(String zipcode){
		String sql="select * from Providerdetails where zipCode='"+zipcode+"';";
		ResultSet rs = null;
		String[] cars= new String[10];
		int ctr=0;
		try{
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while(rs.next()){
				if(rs.getString("zipCode").trim().equals(zipcode)){
					cars[ctr]=rs.getString("carName");
				}
			}
			return cars;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return cars;

	}
	private static Statement statement = null;
	private static Connection connection=null;

}
