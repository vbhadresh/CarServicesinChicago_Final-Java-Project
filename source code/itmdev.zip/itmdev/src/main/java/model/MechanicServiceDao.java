package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class MechanicServiceDao {

	private String zipCode;
	private String carName;
	private int providerId;

	public MechanicServiceDao() {
		this.connection = new daoModel().getConnection();
		if (connection != null) {
			System.out.println("Established Connection successfully");
		} else {
			System.err.println("Failed to establish Connection");
		}
	}
	
	public boolean updateStatus(String id, String zipcode, String desc){
		try {
			statement= connection.createStatement();
			String query="Insert into MechanicService Values("+"'"+id+"',"+"'"+zipcode+"',"+"'"+desc+"')";
			statement.execute(query);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public Map<String,String> getdet(){
		Map<String,String> list=new HashMap<String,String>();
		try{
			
		statement= connection.createStatement();
		ResultSet rs = null;
		String query="Select serviceDesc, zipCode from MechanicService";
		rs=statement.executeQuery(query);
		while(rs.next()){
			list.put(rs.getString("zipCode"),rs.getString("serviceDesc"));
			//list.put(rs.getString(1));
		}
		return list;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	private static Statement statement = null;
	private static Connection connection = null;
}
