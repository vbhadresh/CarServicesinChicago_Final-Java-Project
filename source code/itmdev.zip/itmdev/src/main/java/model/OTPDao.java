package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OTPDao {

	public OTPDao() {
		this.connection=new daoModel().getConnection();
		if (connection != null) {
			System.out.println("Established Connection successfully");
		} else {
			System.err.println("Failed to establish Connection");
		}

	}

	public String getOTP(String email,String otp) {
		String sql = "select OTP from Otp where emailId='"+email+"';";
		ResultSet rs = null;
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while(rs.next()) {
				if(rs.getString("OTP").trim().equals(otp)){
				return rs.getString("OTP");
			}
			else{
				return "OTP doesn't match.Please check your mail id and try again";
			}
		}
		}
			catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public void setOTP(String OTP, String emailId) {
		try {
			statement= connection.createStatement();
			String delete="delete from Otp where emailId='"+emailId+"';";
			statement.execute(delete);
			String query="Insert into Otp Values("+"'"+OTP+"',"+"'"+emailId+"')";
			statement.execute(query);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	private static Statement statement = null;
	private static Connection connection = null;

}
