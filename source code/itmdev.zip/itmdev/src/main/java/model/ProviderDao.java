package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProviderDao {

	private String zipCode;
	private String carName;
	private int providerId;

	public ProviderDao() {
		this.connection = new daoModel().getConnection();
		if (connection != null) {
			System.out.println("Established Connection successfully");
		} else {
			System.err.println("Failed to establish Connection");
		}
	}
	
	public void deleteEntry(String carName){
		String query="delete from Providerdetails where carName='"+carName+"';";
		ResultSet rs = null;
		try{
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String[] getProviderdetails(String custId){
		String[] providerDet= new String[3];
		int ctr=0;
		String sql="select * from Providerdetails where emailId='"+custId+"';";
		ResultSet rs = null;
		try{
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while(rs.next() && ctr<providerDet.length){
				providerDet[ctr]=rs.getString("carName");
				ctr++;
				
			}
			return providerDet;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return providerDet;
	}

	public void setProviderdetails(String custId,String zipcode, String[] cars){
		String query="Select * from Providerdetails;";
		String delete="delete from Providerdetails";
		ResultSet rs = null;
		try{
			statement = connection.createStatement();
			rs=statement.executeQuery(query);
			if(rs.next()){
				if(zipcode.trim().equals(rs.getString("zipcode"))){
					statement.executeUpdate(delete);
					for(String str: cars){
						String sql="Insert into Providerdetails Values('"+custId+"',"+"'"+zipcode+"',"+"'"+str+"');";
						
						try{
							//statement = connection.createStatement();
							statement.executeUpdate(sql);
						}
						catch(Exception e){
							e.printStackTrace();
						}
						}
				}
				else{
					for(String str: cars){
						String sql="Insert into Providerdetails Values('"+custId+"',"+"'"+zipcode+"',"+"'"+str+"');";
						
						try{
							//statement = connection.createStatement();
							statement.executeUpdate(sql);
						}
						catch(Exception e){
							e.printStackTrace();
						}
						}
				}
			}
			
		}
		catch(Exception e){
			
		}
		
	}
	
	public List<String> getzipCodes(){
		String sql="Select Distinct zipCode from providerdetails;";
		String query="Select Count(Distinct zipCode) as total from providerdetails;";
		ResultSet rs = null;
		ResultSet rs1 = null;
		String zip= "";
		int ctr=0;
		int i=0;
		 List<String> list=new ArrayList();
		try{
			statement = connection.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next()){
				list.add(rs.getString(1));
				//list.add(rs.getString(0));
				ctr++;
			}
			//zip=new String[ctr];
			rs1 = statement.executeQuery(query);
			while(rs1.next()){
				if(!(ctr<=0)){
					zip=rs1.getString(1);
					i++;
					
				}
			}
		}
		catch(Exception e){
			
		}
		return list;
	}
	public List<String> getCar(String zip){
		String sql="Select carName from Providerdetails where zipCode='"+zip+"';";
		ResultSet rs = null;
		List<String> list=new ArrayList();
		try{
			statement = connection.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next()){
				list.add(rs.getString(1));
				//list.add(rs.getString(0));
			}
			return list;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	private static Statement statement = null;
	private static Connection connection = null;
}
