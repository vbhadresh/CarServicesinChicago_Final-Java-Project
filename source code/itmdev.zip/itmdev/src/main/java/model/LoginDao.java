package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDao {

	
	public LoginDao(){
		this.connection=new daoModel().getConnection();
		if(connection!=null){
			System.out.println("Established Connection successfully");
		}
		else{
			System.err.println("Failed to establish Connection");
		}
	}
	
	public boolean setCredentials(String custId,String title,String fName, String lName,String pWord,String uType, String email,String uName){
		try {
			statement= connection.createStatement();
			if(checkUser(uName, email)){
				return false;
			}else{
			String query="Insert into login Values("+"'"+custId+"',"+"'"+title+"',"+"'"+fName+"',"+"'"+lName+"',"+"'"+pWord+"',"
			+"'"+uType+"',"+"'"+email+"',"+"'"+uName+"')";
			statement.execute(query);
			return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	public boolean checkUser(String userName, String emailId){
		
		String sql="select * from login where username='"+userName+"',"+"and emailID='"+emailId+"';";
		ResultSet rs = null;
		boolean res=false;
		try{
		statement = connection.createStatement();
		rs = statement.executeQuery(sql);
		while(rs.next()){
			if(rs.getString("username").trim().equals(userName))
				return true;
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
public boolean checkCustId(String custId){
		
		String sql="select * from login where username='"+custId+"';";
		ResultSet rs = null;
		boolean res=false;
		try{
		statement = connection.createStatement();
		rs = statement.executeQuery(sql);
		while(rs.next()){
			if(rs.getString("Customerid").trim().equals(custId))
				return true;
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	public String getCustName(String custId){
		String sql="select * from login where Customerid='"+custId+"';";
		ResultSet rs = null;
		String userName="";
		try{
		statement = connection.createStatement();
		rs = statement.executeQuery(sql);
		while(rs.next()){
			if(rs.getString("username").trim().equals(userName)){
			userName=rs.getString("username");
			}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	/**
	 * To Validate Credentialss
	 * @param userName
	 * @param Password
	 * @return
	 */
	public boolean getDetails(String userName, String Password) {
		String sql="select * from login where username='"+userName+"'"+"and pWord='" +Password+"';";
		ResultSet rs = null;
		try{
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while(rs.next()){
				if(rs.getString("username").trim().equals(userName)&& rs.getString("pWord").trim().equals(Password)){
					uName=rs.getString("username").trim();
					CustomerId=rs.getString("Customerid").trim();
					userType=rs.getString("userType").trim();
					firstName=rs.getString("CustomerFirstName").trim();
					emailId=rs.getString("emailID").trim();
					lastName=rs.getString("CustomerLastName").trim();
					return true;
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;

	}
	private static String uName;
	private static String CustomerId;
	private static String userType;
	private static String firstName;
	private static String emailId;
	
	public String getUserName() {
		return uName;
	}

	public  String getCustomerId() {
		return CustomerId;
	}

	public  String getUserType() {
		return userType;
	}

	public  String getFirstName() {
		return firstName;
	}
	public  String getEmailid() {
		return emailId;
	}
	
	public  String getLastName() {
		return lastName;
	}

	private static String lastName;
	private static Statement statement = null;
	private static Connection connection=null;
}
