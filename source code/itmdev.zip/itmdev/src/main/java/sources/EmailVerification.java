package sources;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import sources.GenerateOTP;
public class EmailVerification{

	private static String from, to, password, msg, sub;
	private static int max = 50, min = 1;
	private static String OTP="";
	
	public static boolean send(String to, String type) {
		
		from = "carserviceschicago@gmail.com";
		password = "Gmail@123";
		sub = "Chicago Car Services";
		msg = "Requested OTP is: ";

		// Get properties object
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		// get Session
		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});
		if(type.equals("otp")|| type=="otp"){
			return sendOTP(to,session);
			
		}
		else{
			MimeMessage message = new MimeMessage(session);
			try {
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
				message.setSubject(sub);
				message.setText("Successfully Booked Car");
				System.out.println(""+message);
				// send message
				Transport.send(message);
				System.out.println("message sent successfully");
				return true;
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
	}
	
	public static boolean sendOTP(String to,Session session){
		// compose message
				try {
					if (!(to == null)) {
						OTP= new GenerateOTP().generateOTP();
						MimeMessage message = new MimeMessage(session);
						message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
						message.setSubject(sub);
						message.setText(msg+OTP);
						//message.setText(OTP);
						System.out.println(""+message);
						// send message
						Transport.send(message);
						System.out.println("message sent successfully");
						return true;
					} else {
						System.out.println("Message not sent");
						return false;
					}
				/*	String OTP= new GenerateOTP().generateOTP();
			        System.out.println("OTP "+OTP);
			        String id=new GenerateOTP().generateRand();
			        System.out.println("Id "+id);*/
					/*daoModel connection=new daoModel();
					connection.getConnection();
					if(connection!=null){
						System.out.println("Established Connection successfully");
						connection.updateOTP(OTP, id);
						return true;
					}else{
						System.err.println("Failed to establish connection");
						return false;
					}*/
				} catch (Exception e) {
					throw new RuntimeException(e);
				}

	}
	
	public String getOtp(){
		return OTP;
	}
}