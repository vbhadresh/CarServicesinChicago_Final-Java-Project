package sources;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class LocationAPI {
	
	public String[] getLatLong(String zipCode) throws Exception {
		int responseCode = 0;
		String latitude,longitude="";
		String[] loc= new String[2];
		String api = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + URLEncoder.encode(zipCode, "UTF-8") + "&sensor=true";
	    URL url = new URL(api);
	    HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
	    httpConnection.connect();
	    responseCode = httpConnection.getResponseCode();
	    if(responseCode == 200)
	    {
	      DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();;
	      Document document = builder.parse(httpConnection.getInputStream());
	      XPathFactory xPathfactory = XPathFactory.newInstance();
	      XPath xpath = xPathfactory.newXPath();
	      XPathExpression expr = xpath.compile("/GeocodeResponse/status");
	      String status = (String)expr.evaluate(document, XPathConstants.STRING);
	      if(status.equals("OK"))
	      {
	         expr = xpath.compile("//geometry/location/lat");
	         latitude = (String)expr.evaluate(document, XPathConstants.STRING);
	         expr = xpath.compile("//geometry/location/lng");
	         longitude = (String)expr.evaluate(document, XPathConstants.STRING);
	         System.out.println(longitude);
	         System.out.println(latitude);
	        // String loc=getUserLocation(latitude, longitude);
	         
	         return new String[] {latitude, longitude};
	      }
	      else
	      {
	         throw new Exception("Error from the API - response status: "+status);
	      }
	    }
		return null;
	}
	
	public String getUserLocation(String zipcode) throws IOException{
		   String userlocation=""; 
		  String readUserFeed = null;
		try {
			String[] loc= getLatLong(zipcode);
			readUserFeed = readUserLocationFeed(loc[0].trim() + "," + loc[1].trim());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  System.out.println("User Location "+readUserFeed);
		   return readUserFeed;
		}

		public static String readUserLocationFeed(String address) throws IOException {
		        URL url = null;
		        HttpURLConnection request=null;
				try {
					url = new URL( "http://maps.google.com/maps/api/geocode/json?latlng=" + address
					       + "&sensor=false");
					request = (HttpURLConnection) url.openConnection();
					request.connect();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  
		   String formattedAddress = "";
		   JsonParser parser = new JsonParser();//from gson
		   JsonElement ele=(JsonElement) parser.parse(new InputStreamReader((InputStream) request.getContent()));
		   JsonObject rootobj = ele.getAsJsonObject();
		   System.out.println(rootobj);
		   if (rootobj.get("results") != null) {
		       JsonArray matches = (JsonArray) rootobj.get("results");
		       JsonObject data = (JsonObject) matches.get(0); //TODO: check if idx=0 exists
		       formattedAddress=data.get("formatted_address").toString();
		       return formattedAddress;
		   }
		  return formattedAddress;
		}

		public static double getShortestDist(double lat2, double lat1, double lon1, double lon2){
			double a = (lat1-lat2)*distPerLat(lat1);
		    double b = (lon1-lon2)*distPerLng(lat1);
		    double res=Math.round(Math.sqrt(a*a+b*b));
		     System.out.println( "Distance "+ Math.round(Math.sqrt(a*a+b*b)));
		    return res;
			
		}
		
		 private static double distPerLng(double lat){
		      return 0.0003121092*Math.pow(lat, 4)
		             +0.0101182384*Math.pow(lat, 3)
		                 -17.2385140059*lat*lat
		             +5.5485277537*lat+111301.967182595;
		    }
		 private static double distPerLat(double lat){
	         return -0.000000487305676*Math.pow(lat, 4)
	             -0.0033668574*Math.pow(lat, 3)
	             +0.4601181791*lat*lat
	             -1.4558127346*lat+110579.25662316;
	 }
}
