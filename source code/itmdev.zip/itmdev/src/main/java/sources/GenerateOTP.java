package sources;

import java.util.Random;

public class GenerateOTP {
	
	
	public String generateOTP(){
		String numbers = "0123456789";
		int len=5;
		char[] OTP= new char[len];
		Random rndm_method = new Random();
		for (int i = 0; i < len; i++)
		{
			OTP[i] =numbers.charAt(rndm_method.nextInt(numbers.length()));
		}
		return String.valueOf(OTP);
	}
	public String generateRand(){
		int max=50;
		int min=1;
		Random rndm_method = new Random();
		int rand=rndm_method.nextInt((max-min)+1)*min;
		return String.valueOf(rand);
	}

}
