function validateInput(){
	var email=document.register.email.value.trim();
	console.log(email);
	var regex="^[a-zA-Z0-9\\.]+@[a-zA-Z\\.]+?\.[a-zA-Z]{2,3}$";
	if(email.match(regex)){
		console.log(email + " true");
		return true;
	}
	else{
		console.log("Error");
		alert("Email ID Pattern Mismatch. Please try with correct input");
		document.login.email.value="";
		document.login.email.focus();
		return false;
	} 
	var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
	var password=document.register.password.value.trim();
	console.log(password);
	if(password.match(strongRegex)){
		console.log(password + " true");
		return true;
	}
	else{
		console.log("Error");
		alert("Password Should contain one Number, one Uppercase letter,one Lower Case Letter, one Special character and minimum of * in length  ");
		document.login.email.value="";
		document.login.email.focus();
		return false;
	} 
}

